<?php
require_once(dirname(__FILE__)."/../../controllers/prerequisite_controller.php");

if(isset($_GET["search_term"])) {
    
}