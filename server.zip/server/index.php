<!--redirect to dashboard file in the view folder-->
<?php
	//redirect to index
	header('Location: view/dashboard.php');
?>

	