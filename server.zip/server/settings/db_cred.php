<?php
//Database credentials
define("DATABASE", "ashesi_apps");
define("SERVER", "localhost");
define("USERNAME", "root");
define("PASSWD", "");

?>