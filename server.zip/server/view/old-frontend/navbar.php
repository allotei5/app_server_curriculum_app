<div data-animation="default" data-collapse="medium" data-duration="400" data-easing="ease" data-easing2="ease" data-doc-height="1" role="banner" class="navbar-light w-nav">
    <div class="container-light-nav w-container">
      <a href="#" class="navbar-light-brand w-nav-brand">
        <div class="company-name-block">CURRICULUM <span class="text-span">APP</span></div>
      </a>
      <nav role="navigation" class="nav-menu w-nav-menu">
        <a href="index.php" class="navbar-light-bold-link w-nav-link" >Home</a>
        <a href="course-prerequisite.php" class="navbar-light-bold-link w-nav-link">COURSE PREREQUISITes</a>
        <a href="view-curriculum.php" class="navbar-light-bold-link w-nav-link">View Curriculum</a>
        <a href="curriculum-tracker.php" aria-current="page" class="navbar-light-bold-link last_link w-nav-link w--current">CURRICULUM TRACKER</a>
        <a href="#" class="navbar-light-navbutton w-button">App Server </a>
      </nav>
      <div class="menu-button w-nav-button">
        <div class="navbar-light-icon w-icon-nav-menu"></div>
      </div>
    </div>
  </div>